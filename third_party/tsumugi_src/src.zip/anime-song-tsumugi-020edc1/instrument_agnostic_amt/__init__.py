"""Instrument-agnostic AMT package."""

