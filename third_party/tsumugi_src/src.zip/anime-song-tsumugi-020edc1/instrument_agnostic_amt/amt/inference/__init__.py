"""Core AMT inference utilities."""

