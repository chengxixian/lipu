"""Core AMT model components."""

