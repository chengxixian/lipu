"""Instrument taxonomy helpers."""

