"""Core AMT training recipe."""
