"""Beat/chord training recipes."""
