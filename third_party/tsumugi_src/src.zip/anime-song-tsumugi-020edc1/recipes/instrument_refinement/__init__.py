"""Instrument-refinement training recipe."""
