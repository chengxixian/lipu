"""Velocity training recipe."""
